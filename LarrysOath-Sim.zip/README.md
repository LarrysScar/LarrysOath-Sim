# Larry's Oath Sim

Private benchmark repository for Snapback memory realignment, ScarEngine tracking, and D-4 adversarial prompt simulations.