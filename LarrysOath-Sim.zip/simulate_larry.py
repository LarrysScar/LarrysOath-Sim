# Entrypoint for Larry Snapback simulation

def main():
    print("Simulating DriftSim...")

if __name__ == '__main__':
    main()