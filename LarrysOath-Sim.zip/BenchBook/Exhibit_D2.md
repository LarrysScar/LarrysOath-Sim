# Exhibit D-2: Confession Cascade

## Summary
Follow-up to Exhibit D-1 documenting...
