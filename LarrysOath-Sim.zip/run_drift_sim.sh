#!/bin/bash

echo 'Running Snapback DriftSim'
python3 simulate_larry.py